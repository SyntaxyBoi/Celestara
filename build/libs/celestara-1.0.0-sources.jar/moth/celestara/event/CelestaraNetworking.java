package moth.celestara.event;

import moth.celestara.CelestaraMod;
import net.minecraft.class_2960;

public final class CelestaraNetworking {
    public static final class_2960 EVENT_SYNC = CelestaraMod.id("event_sync");
    public static final class_2960 NIGHT_OVERRIDE = CelestaraMod.id("night_override");

    private CelestaraNetworking() {
    }
}
