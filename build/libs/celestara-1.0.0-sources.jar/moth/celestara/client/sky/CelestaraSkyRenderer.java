package moth.celestara.client.sky;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public final class CelestaraSkyRenderer {
    private CelestaraSkyRenderer() {
    }

    public static void render(class_4587 matrices, class_638 world, float tickDelta, boolean thickFog) {
        if (matrices == null || world == null || thickFog || !NightSkyPlanManager.isAllowedDimension(world)) {
            return;
        }

        float visibility = nightVisibility(world, tickDelta);
        if (visibility <= CelestaraVisualConstants.MIN_VISIBILITY) {
            return;
        }

        NightSkyPlan plan = NightSkyPlanManager.getPlan(world);
        if (plan == null) {
            return;
        }

        matrices.method_22903();
        float skyRotationDegrees = world.method_30274(tickDelta) * 360.0F;
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-90.0F));
        Matrix4f matrix = matrices.method_23760().method_23761();

        RenderSystem.setShader(class_757::method_34540);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(
                GlStateManager.class_4535.SRC_ALPHA,
                GlStateManager.class_4534.ONE,
                GlStateManager.class_4535.ONE,
                GlStateManager.class_4534.ZERO
        );
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        class_287 buffer = class_289.method_1348().method_1349();
        buffer.method_1328(class_293.class_5596.field_27379, class_290.field_1576);
        double renderTime = world.method_8510() + tickDelta;
        double nightOffset = NightSkyPlanManager.currentNightOffset(world, tickDelta);
        CelestaraStarRenderer.render(matrix, buffer, plan, visibility, renderTime, skyRotationDegrees);
        CelestaraEffectRenderer.render(matrix, buffer, plan, nightOffset, renderTime, visibility, 0.0F);
        class_287.class_7433 builtBuffer = buffer.method_43575();
        if (builtBuffer != null) {
            class_286.method_43433(builtBuffer);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        matrices.method_22909();
    }

    private static float nightVisibility(class_638 world, float tickDelta) {
        // Yarn 1.20.1 leaves this ClientWorld method intermediary-named; it is vanilla star brightness.
        float starBrightness = world.method_23787(tickDelta);
        float rainFade = 1.0F - world.method_8430(tickDelta) * 0.62F;
        float thunderFade = 1.0F - world.method_8478(tickDelta) * 0.24F;
        return class_3532.method_15363(starBrightness * rainFade * thunderFade, 0.0F, 1.0F);
    }
}
