package moth.celestara.client.sky;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import moth.celestara.event.CelestaraEvents;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

import java.util.List;

public final class CelestaraSkyRenderer {
    private CelestaraSkyRenderer() {
    }

    public static void render(class_4587 matrices, class_638 world, float tickDelta, boolean thickFog) {
        if (matrices == null || world == null || thickFog || !NightSkyPlanManager.isAllowedDimension(world)) {
            return;
        }

        float visibility = nightVisibility(world, tickDelta);
        boolean solarEclipse = CelestaraClientEventState.isSolarEclipseActive(world);
        boolean lunarEclipse = CelestaraClientEventState.isLunarEclipseActive(world);
        List<PersistentCometEvent> persistentComets = PersistentCometManager.activeComets(world, tickDelta);
        if (visibility <= CelestaraVisualConstants.MIN_VISIBILITY
                && !solarEclipse
                && !lunarEclipse
                && persistentComets.isEmpty()) {
            return;
        }

        float skyVisibility = solarEclipse
                ? Math.max(visibility, 0.44F * CelestaraClientEventState.solarEclipseFade(world))
                : visibility;
        long eclipsePlanIndex = eclipsePlanIndex(world, solarEclipse, lunarEclipse);
        NightSkyPlan plan = null;
        if (skyVisibility > CelestaraVisualConstants.MIN_VISIBILITY) {
            plan = eclipsePlanIndex == Long.MIN_VALUE
                    ? NightSkyPlanManager.getPlan(world)
                    : NightSkyPlanManager.getPlan(world, eclipsePlanIndex);
        }

        matrices.method_22903();
        float skyRotationDegrees = world.method_30274(tickDelta) * 360.0F;
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-90.0F));
        Matrix4f matrix = matrices.method_23760().method_23761();

        RenderSystem.setShader(class_757::method_34540);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(
                GlStateManager.class_4535.SRC_ALPHA,
                GlStateManager.class_4534.ONE,
                GlStateManager.class_4535.ONE,
                GlStateManager.class_4534.ZERO
        );
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        class_287 buffer = class_289.method_1348().method_1349();
        double renderTime = world.method_8510() + tickDelta;
        double nightOffset = NightSkyPlanManager.currentNightOffset(world, tickDelta);

        buffer.method_1328(class_293.class_5596.field_27379, class_290.field_1576);
        if (plan != null) {
            CelestaraStarRenderer.render(matrix, buffer, plan, skyVisibility, renderTime, skyRotationDegrees);
            CelestaraEffectRenderer.render(matrix, buffer, plan, nightOffset, renderTime, skyVisibility, 0.0F);
        }
        CelestaraEffectRenderer.renderPersistentComets(
                matrix,
                buffer,
                persistentComets,
                world.method_8532() + tickDelta,
                persistentVisibility(visibility, solarEclipse, lunarEclipse, world)
        );
        class_286.method_43433(buffer.method_1326());

        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        matrices.method_22909();
    }

    private static float nightVisibility(class_638 world, float tickDelta) {
        // Yarn 1.20.1 leaves this ClientWorld method intermediary-named; it is vanilla star brightness.
        float starBrightness = world.method_23787(tickDelta);
        float rainFade = 1.0F - world.method_8430(tickDelta) * 0.62F;
        float thunderFade = 1.0F - world.method_8478(tickDelta) * 0.24F;
        return class_3532.method_15363(starBrightness * rainFade * thunderFade, 0.0F, 1.0F);
    }

    private static long eclipsePlanIndex(class_638 world, boolean solarEclipse, boolean lunarEclipse) {
        if (solarEclipse) {
            return CelestaraEvents.visibleSolarEclipseDay(world.method_8532());
        }
        if (lunarEclipse) {
            return CelestaraEvents.visibleLunarEclipseNight(world.method_8532());
        }
        return Long.MIN_VALUE;
    }

    private static float persistentVisibility(float nightVisibility, boolean solarEclipse,
                                              boolean lunarEclipse, class_638 world) {
        float solarFade = solarEclipse ? CelestaraClientEventState.solarEclipseFade(world) : 0.0F;
        float lunarFade = lunarEclipse ? CelestaraClientEventState.lunarEclipseFade(world) : 0.0F;
        float dayVisibility = solarEclipse ? 0.56F * solarFade : 0.18F;
        float lunarBoost = lunarEclipse ? 0.18F * lunarFade : 0.0F;
        return class_3532.method_15363(Math.max(nightVisibility, dayVisibility) + lunarBoost, 0.0F, 1.0F);
    }
}
