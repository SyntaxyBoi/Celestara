package moth.celestara.client.sky;

import moth.butterflyapi.math.Vecs;
import net.minecraft.class_243;

public record SkyPath(class_243 start, class_243 control, class_243 end) {
    public class_243 positionAt(float progress) {
        double t = Math.max(0.0D, Math.min(1.0D, progress));
        double inv = 1.0D - t;
        class_243 point = start.method_1021(inv * inv)
                .method_1019(control.method_1021(2.0D * inv * t))
                .method_1019(end.method_1021(t * t));
        return Vecs.safeNormalize(point, end);
    }

    public class_243 tangentAt(float progress) {
        double t = Math.max(0.0D, Math.min(1.0D, progress));
        class_243 tangent = control.method_1020(start).method_1021(2.0D * (1.0D - t))
                .method_1019(end.method_1020(control).method_1021(2.0D * t));
        return Vecs.safeNormalize(tangent, end.method_1020(start));
    }
}
