package moth.celestara.client.sky;

import moth.celestara.event.CelestaraEvents;
import moth.celestara.event.PersistentCometSeed;
import net.minecraft.class_2960;
import net.minecraft.class_638;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class CelestaraClientEventState {
    private static final Set<class_2960> SERVER_SYNCED_DIMENSIONS = new HashSet<>();
    private static final Map<class_2960, Map<Long, Boolean>> SERVER_SOLAR_ECLIPSES = new HashMap<>();
    private static final Map<class_2960, Map<Long, Boolean>> SERVER_LUNAR_ECLIPSES = new HashMap<>();

    private CelestaraClientEventState() {
    }

    public static void applyServerSnapshot(class_2960 dimension,
                                           Map<Long, Boolean> solarEclipses,
                                           Map<Long, Boolean> lunarEclipses,
                                           List<PersistentCometSeed> persistentComets) {
        SERVER_SYNCED_DIMENSIONS.add(dimension);
        SERVER_SOLAR_ECLIPSES.put(dimension, new HashMap<>(solarEclipses));
        SERVER_LUNAR_ECLIPSES.put(dimension, new HashMap<>(lunarEclipses));
        PersistentCometManager.applyServerSnapshot(dimension, persistentComets);
    }

    public static boolean isSolarEclipseActive(class_638 world) {
        if (!isAllowedWorld(world)) {
            return false;
        }

        long eclipseDay = CelestaraEvents.visibleSolarEclipseDay(world.method_8532());
        if (eclipseDay == Long.MIN_VALUE) {
            return false;
        }

        return isSolarEclipse(world, eclipseDay);
    }

    public static boolean isLunarEclipseActive(class_638 world) {
        if (!isAllowedWorld(world)) {
            return false;
        }

        long eclipseNight = CelestaraEvents.visibleLunarEclipseNight(world.method_8532());
        if (eclipseNight == Long.MIN_VALUE) {
            return false;
        }

        return isLunarEclipse(world, eclipseNight);
    }

    public static boolean isSolarEclipse(class_638 world, long dayIndex) {
        class_2960 dimension = world.method_27983().method_29177();
        if (CelestaraEvents.isSolarEclipseForced(dimension, dayIndex)) {
            return true;
        }

        if (SERVER_SYNCED_DIMENSIONS.contains(dimension)) {
            return SERVER_SOLAR_ECLIPSES.getOrDefault(dimension, Map.of()).getOrDefault(dayIndex, false);
        }

        return CelestaraEvents.isSolarEclipse(world, dayIndex);
    }

    public static boolean isLunarEclipse(class_638 world, long nightIndex) {
        class_2960 dimension = world.method_27983().method_29177();
        if (CelestaraEvents.isLunarEclipseForced(dimension, nightIndex)) {
            return true;
        }

        if (SERVER_SYNCED_DIMENSIONS.contains(dimension)) {
            return SERVER_LUNAR_ECLIPSES.getOrDefault(dimension, Map.of()).getOrDefault(nightIndex, false);
        }

        return CelestaraEvents.isLunarEclipse(world, nightIndex);
    }

    public static boolean hasServerSync(class_638 world) {
        return world != null && SERVER_SYNCED_DIMENSIONS.contains(world.method_27983().method_29177());
    }

    public static float solarEclipseFade(class_638 world) {
        if (!isAllowedWorld(world)) {
            return 0.0F;
        }

        return isSolarEclipseActive(world) ? 1.0F : 0.0F;
    }

    public static float lunarEclipseFade(class_638 world) {
        if (!isAllowedWorld(world) || !isLunarEclipseActive(world)) {
            return 0.0F;
        }

        int phase = CelestaraEvents.dayPhase(world.method_8532());
        int fadeTicks = 600;
        if (phase >= CelestaraEvents.LUNAR_VISIBLE_START_TICK) {
            return Math.min(1.0F, Math.max(0.0F, (phase - CelestaraEvents.LUNAR_VISIBLE_START_TICK) / (float) fadeTicks));
        }

        return Math.min(1.0F, Math.max(0.0F, (CelestaraEvents.LUNAR_VISIBLE_END_TICK - phase) / (float) fadeTicks));
    }

    public static void clear() {
        SERVER_SYNCED_DIMENSIONS.clear();
        SERVER_SOLAR_ECLIPSES.clear();
        SERVER_LUNAR_ECLIPSES.clear();
        PersistentCometManager.clear();
        CelestaraEvents.clearForcedEclipses();
    }

    private static boolean isAllowedWorld(class_638 world) {
        return world != null && NightSkyPlanManager.isAllowedDimension(world);
    }
}
