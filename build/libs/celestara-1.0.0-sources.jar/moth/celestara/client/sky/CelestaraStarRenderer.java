package moth.celestara.client.sky;

import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_3532;
import org.joml.Matrix4f;

public final class CelestaraStarRenderer {
    private CelestaraStarRenderer() {
    }

    public static boolean render(Matrix4f matrix, class_287 buffer, NightSkyPlan plan, float visibility,
                                 double time, float skyRotationDegrees) {
        if (!CelestaraVisualConstants.ENHANCED_STARS_ENABLED || visibility <= CelestaraVisualConstants.MIN_VISIBILITY) {
            return false;
        }

        boolean emitted = false;
        for (StarVisualData star : plan.stars()) {
            float alphaScale = starAlphaScale(star, visibility, time);
            int alpha = Math.round((star.supergiant() ? 220.0F : 185.0F) * alphaScale);
            if (alpha <= 3) {
                continue;
            }

            float layerRotation = skyRotationDegrees * star.layerSpeed();
            double layerRadians = Math.toRadians(layerRotation);
            double layerCos = Math.cos(layerRadians);
            double layerSin = Math.sin(layerRadians);
            class_243 direction = CelestaraSkyGeometry.rotateX(star.direction(), layerCos, layerSin);
            class_243 center = CelestaraSkyGeometry.skyPosition(direction);
            float rotation = star.baseRotation()
                    + class_3532.method_15374((float) (time * star.oscillationSpeed() + star.oscillationPhase())) * star.maxRotationOffset();
            double radians = Math.toRadians(rotation);
            double cos = Math.cos(radians);
            double sin = Math.sin(radians);
            class_243 baseRight = CelestaraSkyGeometry.rotateX(star.basis().right(), layerCos, layerSin);
            class_243 baseUp = CelestaraSkyGeometry.rotateX(star.basis().up(), layerCos, layerSin);
            class_243 right = baseRight.method_1021(cos).method_1019(baseUp.method_1021(sin));
            class_243 up = baseUp.method_1021(cos).method_1020(baseRight.method_1021(sin));

            int starColor = star.color();
            if (star.supergiant()) {
                CelestaraSkyGeometry.emitDiamond(
                        matrix,
                        buffer,
                        center,
                        right,
                        up,
                        star.size() * 2.10F,
                        star.size() * 2.10F,
                        starColor,
                        Math.round(alpha * 0.12F)
                );
            }
            if (star.size() > 0.092F) {
                CelestaraSkyGeometry.emitDiamond(
                        matrix,
                        buffer,
                        center,
                        right,
                        up,
                        star.size() * 1.75F,
                        star.size() * 1.75F,
                        starColor,
                        Math.round(alpha * 0.18F)
                );
            }
            CelestaraSkyGeometry.emitDiamond(
                    matrix,
                    buffer,
                    center,
                    right,
                    up,
                    star.size(),
                    star.size() * 1.12F,
                    starColor,
                    alpha
            );
            if (star.size() > 0.118F) {
                CelestaraSkyGeometry.emitDiamond(
                        matrix,
                        buffer,
                        center,
                        up,
                        right,
                        star.size() * 0.52F,
                        star.size() * 1.42F,
                        starColor,
                        Math.round(alpha * 0.34F)
                );
            }
            emitted = true;
        }
        return emitted;
    }

    private static float starAlphaScale(StarVisualData star, float visibility, double time) {
        float primary = class_3532.method_15374((float) (time * star.twinkleSpeed() + star.twinklePhase()));
        float secondary = class_3532.method_15374((float) (time * star.twinkleSpeed() * 0.37D + star.twinklePhase() * 1.7D));
        float twinkle = 1.0F + primary * star.twinkleAmplitude() + secondary * star.twinkleAmplitude() * 0.32F;
        return class_3532.method_15363(star.baseBrightness() * twinkle * visibility, 0.0F, 1.0F);
    }
}
