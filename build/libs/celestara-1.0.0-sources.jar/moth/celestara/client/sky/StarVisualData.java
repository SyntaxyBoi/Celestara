package moth.celestara.client.sky;

import moth.butterflyapi.math.Basis3;
import net.minecraft.class_243;

public record StarVisualData(
        class_243 direction,
        Basis3 basis,
        float size,
        float baseBrightness,
        int color,
        float baseRotation,
        float twinklePhase,
        float twinkleAmplitude,
        float twinkleSpeed,
        float oscillationPhase,
        float oscillationSpeed,
        float maxRotationOffset,
        float layerSpeed,
        boolean supergiant
) {
}
