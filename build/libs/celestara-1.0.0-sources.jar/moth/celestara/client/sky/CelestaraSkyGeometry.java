package moth.celestara.client.sky;

import net.minecraft.class_243;
import net.minecraft.class_287;
import org.joml.Matrix4f;

public final class CelestaraSkyGeometry {
    private CelestaraSkyGeometry() {
    }

    public static class_243 skyPosition(class_243 direction) {
        return direction.method_1021(CelestaraVisualConstants.SKY_RADIUS);
    }

    public static class_243 rotateX(class_243 vector, float degrees) {
        double radians = Math.toRadians(degrees);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        return new class_243(
                vector.field_1352,
                vector.field_1351 * cos - vector.field_1350 * sin,
                vector.field_1351 * sin + vector.field_1350 * cos
        );
    }

    public static void emitDiamond(Matrix4f matrix, class_287 buffer, class_243 center, class_243 right, class_243 up,
                                   float width, float height, int color, int alpha) {
        if (alpha <= 0 || width <= 0.0F || height <= 0.0F) {
            return;
        }

        class_243 top = center.method_1019(up.method_1021(height));
        class_243 rightPoint = center.method_1019(right.method_1021(width));
        class_243 bottom = center.method_1020(up.method_1021(height));
        class_243 left = center.method_1020(right.method_1021(width));
        emitTriangle(matrix, buffer, top, rightPoint, bottom, color, alpha);
        emitTriangle(matrix, buffer, top, bottom, left, color, alpha);
    }

    public static void emitPentagon(Matrix4f matrix, class_287 buffer, class_243 center, class_243 right, class_243 up,
                                    float radius, float rotationDegrees, int color, int alpha) {
        if (alpha <= 0 || radius <= 0.0F) {
            return;
        }

        double rotation = Math.toRadians(rotationDegrees) - Math.PI * 0.5D;
        class_243 previous = pentagonPoint(center, right, up, radius, rotation);
        for (int point = 1; point <= CelestaraVisualConstants.HEAD_PENTAGON_POINTS; point++) {
            double angle = rotation + (Math.PI * 2.0D * point) / CelestaraVisualConstants.HEAD_PENTAGON_POINTS;
            class_243 next = pentagonPoint(center, right, up, radius, angle);
            emitTriangle(matrix, buffer, center, previous, next, color, alpha);
            previous = next;
        }
    }

    public static void emitQuad(Matrix4f matrix, class_287 buffer, class_243 first, class_243 second, class_243 third,
                                class_243 fourth, int color, int firstAlpha, int secondAlpha) {
        emitVertex(matrix, buffer, first, color, firstAlpha);
        emitVertex(matrix, buffer, second, color, firstAlpha);
        emitVertex(matrix, buffer, third, color, secondAlpha);
        emitVertex(matrix, buffer, first, color, firstAlpha);
        emitVertex(matrix, buffer, third, color, secondAlpha);
        emitVertex(matrix, buffer, fourth, color, secondAlpha);
    }

    public static void emitTriangle(Matrix4f matrix, class_287 buffer, class_243 first, class_243 second, class_243 third,
                                    int color, int alpha) {
        emitVertex(matrix, buffer, first, color, alpha);
        emitVertex(matrix, buffer, second, color, alpha);
        emitVertex(matrix, buffer, third, color, alpha);
    }

    public static void emitVertex(Matrix4f matrix, class_287 buffer, class_243 position, int color, int alpha) {
        buffer.method_22918(matrix, (float) position.field_1352, (float) position.field_1351, (float) position.field_1350)
                .method_1336(
                        CelestialColorPalette.red(color),
                        CelestialColorPalette.green(color),
                        CelestialColorPalette.blue(color),
                        Math.max(0, Math.min(255, alpha))
                )
                .method_1344();
    }

    private static class_243 pentagonPoint(class_243 center, class_243 right, class_243 up, float radius, double angle) {
        return center
                .method_1019(right.method_1021(Math.cos(angle) * radius))
                .method_1019(up.method_1021(Math.sin(angle) * radius));
    }
}
