package moth.celestara.client.sky;

import java.util.List;
import net.minecraft.class_2960;

public record NightSkyPlan(
        class_2960 dimension,
        long nightIndex,
        long seed,
        float starCountMultiplier,
        NightSkyMood mood,
        boolean forcedMood,
        boolean meteorShower,
        boolean forcedMeteorShower,
        boolean forcedCommandComet,
        List<StarVisualData> stars,
        List<ShootingStarEvent> shootingStars,
        List<CometEvent> comets,
        int maxShootingStarDuration,
        int maxCometDuration
) {
}
