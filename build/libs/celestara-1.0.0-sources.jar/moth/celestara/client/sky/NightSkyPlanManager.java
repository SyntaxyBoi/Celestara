package moth.celestara.client.sky;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5294;
import net.minecraft.class_638;

public final class NightSkyPlanManager {
    private static final Map<PlanKey, ForcedNightSkyOptions> FORCED_OPTIONS = new HashMap<>();
    private static NightSkyPlan currentPlan;

    private NightSkyPlanManager() {
    }

    public static NightSkyPlan getPlan(class_638 world) {
        if (!isAllowedDimension(world)) {
            currentPlan = null;
            return null;
        }

        int phase = dayPhase(world.method_8532());
        if (phase < CelestaraVisualConstants.NIGHT_START_TICK) {
            return currentPlan;
        }

        class_2960 dimension = world.method_27983().method_29177();
        long nightIndex = nightIndexForTime(world.method_8532());
        if (currentPlan != null
                && currentPlan.nightIndex() == nightIndex
                && currentPlan.dimension().equals(dimension)) {
            return currentPlan;
        }

        PlanKey key = new PlanKey(dimension, nightIndex);
        ForcedNightSkyOptions options = FORCED_OPTIONS.getOrDefault(key, ForcedNightSkyOptions.NONE);
        currentPlan = NightSkyPlanGenerator.generate(world, nightIndex, options);
        return currentPlan;
    }

    public static void applyCommandOverride(class_2960 dimension, long timeOfDay,
                                            ForcedNightEvent event, boolean enabled) {
        PlanKey key = new PlanKey(dimension, nightIndexForTime(timeOfDay));
        ForcedNightSkyOptions existing = FORCED_OPTIONS.getOrDefault(key, ForcedNightSkyOptions.NONE);
        ForcedNightSkyOptions updated;
        int offset = nightOffsetForTime(timeOfDay);

        if (event == ForcedNightEvent.METEOR_SHOWER) {
            updated = existing.withMeteorShower(enabled);
        } else if (enabled && existing.forceMeteorShower()) {
            updated = existing;
        } else {
            updated = existing.withCommandComet(enabled, offset);
        }

        if (updated.isEmpty()) {
            FORCED_OPTIONS.remove(key);
        } else {
            FORCED_OPTIONS.put(key, updated);
        }

        if (currentPlan != null
                && currentPlan.nightIndex() == key.nightIndex()
                && currentPlan.dimension().equals(key.dimension())) {
            currentPlan = null;
        }
    }

    public static void clear() {
        currentPlan = null;
        FORCED_OPTIONS.clear();
    }

    public static boolean isAllowedDimension(class_638 world) {
        return world != null
                && class_1937.field_25179.equals(world.method_27983())
                && world.method_28103().method_29992() == class_5294.class_5401.field_25640;
    }

    public static double currentNightOffset(class_638 world, float tickDelta) {
        int phase = dayPhase(world.method_8532());
        if (phase < CelestaraVisualConstants.NIGHT_START_TICK) {
            return -1.0D;
        }
        return class_3532.method_15350(
                phase - CelestaraVisualConstants.NIGHT_START_TICK + tickDelta,
                0.0D,
                CelestaraVisualConstants.NIGHT_DURATION_TICKS
        );
    }

    public static long nightIndexForTime(long timeOfDay) {
        return Math.floorDiv(timeOfDay, CelestaraVisualConstants.DAY_LENGTH_TICKS);
    }

    public static int nightOffsetForTime(long timeOfDay) {
        int phase = dayPhase(timeOfDay);
        if (phase < CelestaraVisualConstants.NIGHT_START_TICK) {
            return 0;
        }
        return class_3532.method_15340(
                phase - CelestaraVisualConstants.NIGHT_START_TICK,
                0,
                CelestaraVisualConstants.NIGHT_DURATION_TICKS
        );
    }

    private static int dayPhase(long timeOfDay) {
        return (int) Math.floorMod(timeOfDay, CelestaraVisualConstants.DAY_LENGTH_TICKS);
    }

    private record PlanKey(class_2960 dimension, long nightIndex) {
    }
}
