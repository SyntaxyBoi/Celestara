package moth.celestara.client;

import com.mojang.brigadier.CommandDispatcher;
import moth.celestara.client.sky.ForcedNightEvent;
import moth.celestara.client.sky.NightSkyPlanManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7157;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class CelestaraClientCommands {
    private static final int TIME_NIGHT = 13000;
    private static final int TIME_MIDNIGHT = 18000;

    private CelestaraClientCommands() {
    }

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher,
                                class_7157 registryAccess) {
        dispatcher.register(literal("celestara")
                .then(literal("time")
                        .then(literal("set")
                                .then(literal("night")
                                        .then(literal("comet")
                                                .then(literal("true")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_NIGHT, "night", ForcedNightEvent.COMET, true)))
                                                .then(literal("false")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_NIGHT, "night", ForcedNightEvent.COMET, false))))
                                        .then(literal("meteor_shower")
                                                .then(literal("true")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_NIGHT, "night", ForcedNightEvent.METEOR_SHOWER, true)))
                                                .then(literal("false")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_NIGHT, "night", ForcedNightEvent.METEOR_SHOWER, false)))))
                                .then(literal("midnight")
                                        .then(literal("comet")
                                                .then(literal("true")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_MIDNIGHT, "midnight", ForcedNightEvent.COMET, true)))
                                                .then(literal("false")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_MIDNIGHT, "midnight", ForcedNightEvent.COMET, false))))
                                        .then(literal("meteor_shower")
                                                .then(literal("true")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_MIDNIGHT, "midnight", ForcedNightEvent.METEOR_SHOWER, true)))
                                                .then(literal("false")
                                                        .executes(context -> setNightEvent(context.getSource(), TIME_MIDNIGHT, "midnight", ForcedNightEvent.METEOR_SHOWER, false))))))));
    }

    private static int setNightEvent(FabricClientCommandSource source, int timeOfDay, String timeName,
                                     ForcedNightEvent event, boolean enabled) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null || client.method_1562() == null) {
            source.sendFeedback(class_2561.method_43470("Celestara can only force night sky events while in a world."));
            return 0;
        }

        long currentDay = Math.floorDiv(client.field_1687.method_8532(), 24000L);
        long targetTime = currentDay * 24000L + timeOfDay;
        class_2960 dimension = client.field_1687.method_27983().method_29177();
        NightSkyPlanManager.applyCommandOverride(dimension, targetTime, event, enabled);

        client.method_1562().method_45730("time set " + timeName);
        source.sendFeedback(feedback(timeName, event, enabled));
        return (int) targetTime;
    }

    private static class_2561 feedback(String timeName, ForcedNightEvent event, boolean enabled) {
        String eventName = event == ForcedNightEvent.METEOR_SHOWER ? "meteor shower" : "comet";
        if (event == ForcedNightEvent.COMET && enabled) {
            return class_2561.method_43470("Celestara queued a client-side early comet and asked the server to set time to " + timeName + ".");
        }
        if (event == ForcedNightEvent.METEOR_SHOWER && enabled) {
            return class_2561.method_43470("Celestara forced a client-side meteor shower and asked the server to set time to " + timeName + ".");
        }
        return class_2561.method_43470("Celestara cleared the forced client-side " + eventName + " override and asked the server to set time to " + timeName + ".");
    }
}
