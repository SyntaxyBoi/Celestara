package moth.celestara.client.mixin;

import moth.celestara.event.CelestaraEvents;
import net.minecraft.class_3149;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3149.class)
public abstract class TimeCommandMixin {
    @Redirect(
            method = "executeSet",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;setTimeOfDay(J)V")
    )
    private static void celestara$setDayTimeWithoutResettingDay(class_3218 world, long requestedTime) {
        long currentDay = CelestaraEvents.dayIndex(world.method_8532());
        long requestedPhase = Math.floorMod(requestedTime, CelestaraEvents.DAY_LENGTH_TICKS);
        world.method_29199(currentDay * CelestaraEvents.DAY_LENGTH_TICKS + requestedPhase);
    }
}
