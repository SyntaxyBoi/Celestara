package moth.celestara.client.mixin;

import moth.celestara.client.sky.CelestaraClientEventState;
import net.minecraft.class_310;
import net.minecraft.class_5294;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5294.class)
public abstract class DimensionEffectsEclipseMixin {
    @Inject(method = "getFogColorOverride", at = @At("HEAD"), cancellable = true)
    private void celestara$removeSolarEclipseSunriseGradient(float skyAngle, float tickDelta,
                                                             CallbackInfoReturnable<float[]> cir) {
        class_638 world = class_310.method_1551().field_1687;
        if (CelestaraClientEventState.isSolarEclipseActive(world)) {
            cir.setReturnValue(null);
        }
    }
}
