package moth.celestara.client.mixin;

import moth.celestara.client.sky.CelestaraSkyRenderer;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class WorldRendererSkyMixin {
    @Shadow
    @Final
    private class_310 client;

    @Inject(
            method = "renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V",
            at = @At("TAIL")
    )
    private void celestara$renderNightSky(class_4587 matrices, Matrix4f projectionMatrix, float tickDelta,
                                          class_4184 camera, boolean thickFog, Runnable fogCallback, CallbackInfo ci) {
        CelestaraSkyRenderer.render(matrices, client.field_1687, tickDelta, thickFog);
    }
}
