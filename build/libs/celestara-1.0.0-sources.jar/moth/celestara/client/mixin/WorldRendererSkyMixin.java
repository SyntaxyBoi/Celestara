package moth.celestara.client.mixin;

import moth.celestara.client.sky.CelestaraSkyRenderer;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import moth.celestara.client.sky.CelestaraClientEventState;
import moth.celestara.CelestaraMod;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class WorldRendererSkyMixin {
    private static final class_2960 CELESTARA_ECLIPSED_SUN = CelestaraMod.id("textures/environment/eclipsed_sun.png");
    private static final class_2960 CELESTARA_ECLIPSED_MOON_PHASES = CelestaraMod.id("textures/environment/eclipsed_moon_phases.png");

    @Shadow
    @Final
    private class_310 client;

    @Inject(
            method = "renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V",
            at = @At("TAIL")
    )
    private void celestara$renderNightSky(class_4587 matrices, Matrix4f projectionMatrix, float tickDelta,
                                          class_4184 camera, boolean thickFog, Runnable fogCallback, CallbackInfo ci) {
        CelestaraSkyRenderer.render(matrices, client.field_1687, tickDelta, thickFog);
    }

    @ModifyArg(
            method = "renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V",
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;setShaderTexture(ILnet/minecraft/util/Identifier;)V", ordinal = 0),
            index = 1
    )
    private class_2960 celestara$replaceSunTexture(class_2960 original) {
        if (client.field_1687 != null && CelestaraClientEventState.isSolarEclipseActive(client.field_1687)) {
            return CELESTARA_ECLIPSED_SUN;
        }
        return original;
    }

    @ModifyArg(
            method = "renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V",
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;setShaderTexture(ILnet/minecraft/util/Identifier;)V", ordinal = 1),
            index = 1
    )
    private class_2960 celestara$replaceMoonTexture(class_2960 original) {
        if (client.field_1687 != null && CelestaraClientEventState.isLunarEclipseActive(client.field_1687)) {
            return CELESTARA_ECLIPSED_MOON_PHASES;
        }
        return original;
    }
}
