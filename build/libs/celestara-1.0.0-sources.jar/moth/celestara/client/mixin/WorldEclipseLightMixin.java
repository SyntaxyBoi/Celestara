package moth.celestara.client.mixin;

import moth.celestara.event.CelestaraEvents;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1937.class)
public abstract class WorldEclipseLightMixin {
    @Shadow
    private int ambientDarkness;

    @Inject(method = "calculateAmbientDarkness", at = @At("TAIL"))
    private void celestara$darkenSolarEclipse(CallbackInfo ci) {
        class_1937 world = (class_1937) (Object) this;
        if (CelestaraEvents.isSolarEclipseActive(world)) {
            ambientDarkness = Math.max(ambientDarkness, 11);
        }
    }
}
