package moth.celestara.client.mixin;

import moth.celestara.client.sky.CelestaraClientEventState;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_638.class)
public abstract class ClientWorldEclipseVisualMixin {
    private static final class_243 SOLAR_SKY_COLOR = new class_243(0.003D, 0.004D, 0.009D);
    private static final class_243 LUNAR_SKY_COLOR = new class_243(0.19D, 0.035D, 0.032D);
    private static final class_243 SOLAR_CLOUD_COLOR = new class_243(0.020D, 0.022D, 0.030D);
    private static final class_243 LUNAR_CLOUD_COLOR = new class_243(0.36D, 0.08D, 0.07D);

    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void celestara$tintSkyColor(class_243 cameraPos, float tickDelta, CallbackInfoReturnable<class_243> cir) {
        class_638 world = (class_638) (Object) this;
        if (CelestaraClientEventState.isSolarEclipseActive(world)) {
            cir.setReturnValue(mix(cir.getReturnValue(), SOLAR_SKY_COLOR, CelestaraClientEventState.solarEclipseFade(world)));
        } else if (CelestaraClientEventState.isLunarEclipseActive(world)) {
            cir.setReturnValue(mix(cir.getReturnValue(), LUNAR_SKY_COLOR, 0.48F * CelestaraClientEventState.lunarEclipseFade(world)));
        }
    }

    @Inject(method = "getCloudsColor", at = @At("RETURN"), cancellable = true)
    private void celestara$tintCloudsColor(float tickDelta, CallbackInfoReturnable<class_243> cir) {
        class_638 world = (class_638) (Object) this;
        if (CelestaraClientEventState.isSolarEclipseActive(world)) {
            cir.setReturnValue(mix(cir.getReturnValue(), SOLAR_CLOUD_COLOR, CelestaraClientEventState.solarEclipseFade(world)));
        } else if (CelestaraClientEventState.isLunarEclipseActive(world)) {
            cir.setReturnValue(mix(cir.getReturnValue(), LUNAR_CLOUD_COLOR, 0.42F * CelestaraClientEventState.lunarEclipseFade(world)));
        }
    }

    @Inject(method = "getSkyBrightness", at = @At("RETURN"), cancellable = true)
    private void celestara$solarEclipseSkyBrightness(float tickDelta, CallbackInfoReturnable<Float> cir) {
        class_638 world = (class_638) (Object) this;
        if (CelestaraClientEventState.isSolarEclipseActive(world)) {
            cir.setReturnValue(Math.min(cir.getReturnValue(), 0.20F));
        }
    }

    @Inject(method = "method_23787", at = @At("RETURN"), cancellable = true)
    private void celestara$solarEclipseStarBrightness(float tickDelta, CallbackInfoReturnable<Float> cir) {
        class_638 world = (class_638) (Object) this;
        if (CelestaraClientEventState.isSolarEclipseActive(world)) {
            float eclipseBrightness = 0.50F * CelestaraClientEventState.solarEclipseFade(world);
            cir.setReturnValue(Math.max(cir.getReturnValue(), eclipseBrightness));
        }
    }

    private static class_243 mix(class_243 original, class_243 target, float amount) {
        double t = class_3532.method_15363(amount, 0.0F, 1.0F);
        return new class_243(
                class_3532.method_16436(t, original.field_1352, target.field_1352),
                class_3532.method_16436(t, original.field_1351, target.field_1351),
                class_3532.method_16436(t, original.field_1350, target.field_1350)
        );
    }
}
