package software.bernie.geckolib.network.packet;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.network.AbstractPacket;
import software.bernie.geckolib.network.GeckoLibNetwork;
import software.bernie.geckolib.network.SerializableDataTicket;
import software.bernie.geckolib.util.ClientUtils;

/**
 * Packet for syncing user-definable animation data for
 * {@link net.minecraft.entity.Entity Entities}
 */
public class EntityAnimDataSyncPacket<D> extends AbstractPacket {
	private final int ENTITY_ID;
	private final SerializableDataTicket<D> DATA_TICKET;
	private final D DATA;

	public EntityAnimDataSyncPacket(int entityId, SerializableDataTicket<D> dataTicket, D data) {
		this.ENTITY_ID = entityId;
		this.DATA_TICKET = dataTicket;
		this.DATA = data;
	}

	@Override
	public PacketByteBuf encode() {
		PacketByteBuf buf = PacketByteBufs.create();

		buf.writeVarInt(this.ENTITY_ID);
		buf.writeString(this.DATA_TICKET.id());
		this.DATA_TICKET.encode(this.DATA, buf);

		return buf;
	}

	@Override
	public Identifier getPacketID() {
		return GeckoLibNetwork.ENTITY_ANIM_DATA_SYNC_PACKET_ID;
	}

	public static <D> void receive(MinecraftClient client, ClientPlayNetworkHandler handler, PacketByteBuf buf, PacketSender responseSender) {
		final int ENTITY_ID = buf.readVarInt();
		final SerializableDataTicket<D> DATA_TICKET = (SerializableDataTicket<D>) DataTickets.byName(buf.readString());
		final D DATA = DATA_TICKET.decode(buf);

		client.execute(() -> runOnThread(ENTITY_ID, DATA_TICKET, DATA));
	}

	private static <D> void runOnThread(int entityId, SerializableDataTicket<D> dataTicket, D data) {
		Entity entity = ClientUtils.getLevel().getEntityById(entityId);

		if (entity instanceof GeoEntity geoEntity)
			geoEntity.setAnimData(dataTicket, data);
	}
}
