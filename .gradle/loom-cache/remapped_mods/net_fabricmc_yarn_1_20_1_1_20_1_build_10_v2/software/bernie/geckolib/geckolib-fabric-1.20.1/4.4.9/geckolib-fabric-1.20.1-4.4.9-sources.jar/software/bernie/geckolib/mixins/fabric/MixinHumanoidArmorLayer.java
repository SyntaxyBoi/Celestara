package software.bernie.geckolib.mixins.fabric;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import software.bernie.geckolib.animatable.client.RenderProvider;

/**
 * Render hook for injecting GeckoLib's armor rendering functionalities
 */
@Mixin(value = ArmorFeatureRenderer.class, priority = 700)
public abstract class MixinHumanoidArmorLayer<T extends LivingEntity, A extends BipedEntityModel<T>> {
    @Unique
    private LivingEntity gl_storedEntity;
    @Unique
    private EquipmentSlot gl_storedSlot;
    @Unique
    private ItemStack gl_storedItemStack;

    @Inject(method = "renderArmorPiece", at = @At(value = "HEAD"))
    public void armorModelHook(MatrixStack poseStack, VertexConsumerProvider multiBufferSource, T livingEntity, EquipmentSlot equipmentSlot, int i, A humanoidModel, CallbackInfo ci) {
        this.gl_storedEntity = livingEntity;
        this.gl_storedSlot = equipmentSlot;
        this.gl_storedItemStack = livingEntity.getEquippedStack(equipmentSlot);
    }

    @ModifyArg(method = "renderArmorPiece", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/layers/HumanoidArmorLayer;renderModel(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/item/ArmorItem;Lnet/minecraft/client/model/HumanoidModel;ZFFFLjava/lang/String;)V"), index = 4)
    public A injectArmor(A humanoidModel) {
        return (A)RenderProvider.of(this.gl_storedItemStack).getGenericArmorModel(this.gl_storedEntity, this.gl_storedItemStack, this.gl_storedSlot, (BipedEntityModel<LivingEntity>) humanoidModel);
    }
}
