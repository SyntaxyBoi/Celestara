package software.bernie.example.registry;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.GeckoLib;

public final class SoundRegistry {

	public static SoundEvent JACK_MUSIC = Registry.register(Registries.SOUND_EVENT, "jack_in_the_box_music",
			SoundEvent.of(new Identifier(GeckoLib.MOD_ID, "jack_in_the_box_music"), 0));

}
