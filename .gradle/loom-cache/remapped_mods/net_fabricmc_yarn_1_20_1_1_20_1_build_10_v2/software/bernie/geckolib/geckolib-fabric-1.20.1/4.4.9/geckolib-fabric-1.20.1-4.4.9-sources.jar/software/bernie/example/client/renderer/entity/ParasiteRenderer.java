package software.bernie.example.client.renderer.entity;

import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.example.client.model.entity.ParasiteModel;
import software.bernie.example.entity.ParasiteEntity;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * Example {@link software.bernie.geckolib.renderer.GeoRenderer} implementation of an entity
 * @see ParasiteModel
 * @see ParasiteEntity
 */
public class ParasiteRenderer extends GeoEntityRenderer<ParasiteEntity> {
	public ParasiteRenderer(EntityRendererFactory.Context renderManager) {
		super(renderManager, new ParasiteModel());
	}
}
