package software.bernie.geckolib.mixins.fabric;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.BuiltinModelItemRenderer;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import software.bernie.geckolib.animatable.client.RenderProvider;

/**
 * Render hook to inject GeckoLib's ISTER rendering callback
 */
@Mixin(ItemRenderer.class)
public class MixinItemRenderer {
    // Done in two parts so that the cancellation of the vanilla render can fail-safe without breaking functionality

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/BlockEntityWithoutLevelRenderer;renderByItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V"))
    public void itemModelHook(ItemStack itemStack, ModelTransformationMode transformType, boolean bl, MatrixStack poseStack, VertexConsumerProvider multiBufferSource, int i, int j, BakedModel bakedModel, CallbackInfo ci) {
       final BuiltinModelItemRenderer renderer = RenderProvider.of(itemStack).getCustomRenderer();

       if (renderer != RenderProvider.DEFAULT.getCustomRenderer())
           renderer.render(itemStack, transformType, poseStack, multiBufferSource, i, j);
    }

    @Redirect(method = "render", require = 0, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/BlockEntityWithoutLevelRenderer;renderByItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V"))
    public void cancelRender(BuiltinModelItemRenderer renderer, ItemStack itemStack, ModelTransformationMode displayContext, MatrixStack poseStack, VertexConsumerProvider bufferSource, int i, int j) {
        if (RenderProvider.of(itemStack).getCustomRenderer() == renderer)
            renderer.render(itemStack, displayContext, poseStack, bufferSource, i, j);
    }
}
